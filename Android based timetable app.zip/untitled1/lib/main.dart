import 'package:flutter/material.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'College Timetable',
      theme: ThemeData(
        primarySwatch: Colors.blue,
        textTheme: TextTheme(
          bodyMedium: TextStyle(fontSize: 16),
        ),
      ),
      home: TimetableScreen(),
    );
  }
}

class TimetableScreen extends StatefulWidget {
  @override
  _TimetableScreenState createState() => _TimetableScreenState();
}

class _TimetableScreenState extends State<TimetableScreen> {
  String? selectedBranch = 'None';
  String? selectedSemester = 'None';
  String? selectedSection = 'None';

  String? timetableUrl;
  bool isLoading = false;

  final Map<String, String> dummyTimetables = {
    'ECES1A': 'https://siri3005.github.io/timetable-images/ECE-H.png',
    'ECES1B': 'https://siri3005.github.io/timetable-images/ECE-G.png',
    'ECES1C': 'https://siri3005.github.io/timetable-images/ECE-I.png',
    'EACS1A': 'https://siri3005.github.io/timetable-images/EAC-J.png',
    'EEES1A': 'https://siri3005.github.io/timetable-images/EEE-K.png',
    'AIDSS1A': 'https://siri3005.github.io/timetable-images/AID-F.png',
    'CSES1A': 'https://siri3005.github.io/timetable-images/CSE-A.png',
    'CSES1B': 'https://siri3005.github.io/timetable-images/CSE-B.png',
    'CSES1C': 'https://siri3005.github.io/timetable-images/CSE-C.png',
    'CSEAIS1A': 'https://siri3005.github.io/timetable-images/AIE-D.png',
    'CSEAIS1B': 'https://siri3005.github.io/timetable-images/AIE-E.png',
    'ELCS1A': 'https://siri3005.github.io/timetable-images/ELC-L.png',
  };

  bool isSingleSectionBranch(String branch) {
    return ['EEE', 'EAC', 'ELC', 'MECH', 'RAI', 'AIDS'].contains(branch);
  }

  bool isSelectionValid() {
    return selectedBranch != 'None' &&
        selectedSemester != 'None' &&
        selectedSection != 'None';
  }

  void fetchTimetable() async {
    if (!isSelectionValid()) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Please complete all selections')),
      );
      setState(() {
        timetableUrl = null;
      });
      return;
    }

    String key = '${selectedBranch}${selectedSemester}${selectedSection}';
    print("Constructed key: $key"); // Debug print

    if (dummyTimetables.containsKey(key)) {
      setState(() {
        timetableUrl = dummyTimetables[key];
        isLoading = false;
      });
    } else {
      print("No timetable available for key: $key"); // Debug print
      setState(() {
        timetableUrl = null;
        isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[50],
      body: SingleChildScrollView(
        child: Column(
          children: [
            Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [Colors.white, Colors.blue[50]!],
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                ),
              ),
              padding: const EdgeInsets.all(20.0),
              child: Column(
                children: [
                  Image.network(
                    'https://siri3005.github.io/timetable-images/Amrita-Logo.jpg',
                    height: 120,
                  ),
                  SizedBox(height: 15),
                  Text(
                    'TIMETABLE',
                    style: TextStyle(
                      fontSize: 28,
                      fontWeight: FontWeight.bold,
                      color: Colors.black,
                    ),
                    textAlign: TextAlign.center,
                  ),
                ],
              ),
            ),
            Divider(height: 30, thickness: 1.5, color: Colors.blueGrey),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20.0),
              child: Column(
                children: [
                  _buildDropdown(
                    label: 'Select Branch',
                    value: selectedBranch,
                    items: [
                      'None',
                      'CSE',
                      'CSEAI',
                      'AIDS',
                      'RAI',
                      'ECE',
                      'EAC',
                      'EEE',
                      'ELC',
                      'MECH',
                    ],
                    onChanged: (value) {
                      setState(() {
                        selectedBranch = value!;
                        if (isSingleSectionBranch(selectedBranch!)) {
                          selectedSection = 'A';
                        } else {
                          selectedSection = 'None';
                        }
                        fetchTimetable();
                      });
                    },
                  ),
                  SizedBox(height: 20),
                  _buildDropdown(
                    label: 'Select Semester',
                    value: selectedSemester,
                    items: [
                      'None',
                      ...List.generate(8, (index) => 'S${index + 1}')
                    ],
                    onChanged: (value) {
                      setState(() {
                        selectedSemester = value!;
                        fetchTimetable();
                      });
                    },
                  ),
                  if (!isSingleSectionBranch(selectedBranch!))
                    SizedBox(height: 20),
                  if (!isSingleSectionBranch(selectedBranch!))
                    _buildDropdown(
                      label: 'Select Section',
                      value: selectedSection,
                      items: ['None', 'A', 'B', 'C'],
                      onChanged: (value) {
                        setState(() {
                          selectedSection = value!;
                          fetchTimetable();
                        });
                      },
                    ),
                ],
              ),
            ),
            Divider(height: 30, thickness: 1.5, color: Colors.blueGrey),
            isLoading
                ? Padding(
                    padding: const EdgeInsets.all(20.0),
                    child: CircularProgressIndicator(),
                  )
                : timetableUrl == null
                    ? Padding(
                        padding: const EdgeInsets.all(20.0),
                        child: Text(
                          'No timetable available for the selected options.',
                          style: TextStyle(fontSize: 18, color: Colors.red),
                          textAlign: TextAlign.center,
                        ),
                      )
                    : Padding(
                        padding: const EdgeInsets.all(20.0),
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(12),
                          child: Image.network(
                            timetableUrl!,
                            fit: BoxFit.cover,
                          ),
                        ),
                      ),
          ],
        ),
      ),
    );
  }

  Widget _buildDropdown({
    required String label,
    required String? value,
    required List<String> items,
    required ValueChanged<String?> onChanged,
  }) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: Colors.grey,
            blurRadius: 8,
            spreadRadius: 2,
            offset: Offset(0, 4),
          ),
        ],
      ),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
        child: DropdownButtonFormField<String>(
          decoration: InputDecoration(
            labelText: label,
            border: InputBorder.none,
          ),
          value: value,
          onChanged: onChanged,
          items: items.map((item) {
            return DropdownMenuItem<String>(
              value: item,
              child: Text(item),
            );
          }).toList(),
        ),
      ),
    );
  }
}
